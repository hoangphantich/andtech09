/**
 * http://iziroi.9xkun.com
 *
 * LICENSE
 *
 * This source file is belong to iziroi.9xkun.com. Please come to this site and
 * get more source code. Can send email to me at: phantichhoang@gmail.com
 *
 * @copyright Copyright (c) 2013-2014 iziroi
 * @author hoangpt
 * @version $Id$
 * @since
 */

package com.hoangphan.events;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;

public class EventUseLayoutDefineListenerActivity extends Activity {

  private View regionColor;

  /**
   * Called when the activity is first created.
   */
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);

    regionColor = findViewById(R.id.color_region);
    Button b1 = (Button) findViewById(R.id.button1);
    Button b2 = (Button) findViewById(R.id.button2);
    Button b3 = (Button) findViewById(R.id.button3);
    RadioButton r1 = (RadioButton) findViewById(R.id.radio_button1);
    RadioButton r2 = (RadioButton) findViewById(R.id.radio_button2);
    RadioButton r3 = (RadioButton) findViewById(R.id.radio_button3);
  }

public void onClickButton(View v){
    int id = v.getId();
    switch (id) {
      case R.id.button1:
        setRegionColor(Color.RED);
        break;
      case R.id.button2:
        setRegionColor(Color.BLUE);
        break;
      case R.id.button3:
        setRegionColor(Color.YELLOW);
        break;
      case R.id.radio_button1:
        setRegionColor(Color.RED);
        break;
      case R.id.radio_button2:
        setRegionColor(Color.BLUE);
        break;
      case R.id.radio_button3:
        setRegionColor(Color.YELLOW);
        break;
    }
}
  
  /**
   * Sets the color of the color region.
   */
  private void setRegionColor(int color) {
    regionColor.setBackgroundColor(color);
  }

}
