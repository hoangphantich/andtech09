/**
 * http://iziroi.9xkun.com
 *
 * LICENSE
 *
 * This source file is belong to iziroi.9xkun.com. Please come to this site and
 * get more source code. Can send email to me at: phantichhoang@gmail.com
 *
 * @copyright Copyright (c) 2013-2014 iziroi
 * @author hoangpt
 * @version $Id$
 * @since
 */

package com.hoangphan.wizard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

/**
 *
 * @author hoangpt
 */
public class Step3 extends Activity {
  private EditText txtPhone;

  /**
   * Called when the activity is first created.
   */
  @Override
  public void onCreate(Bundle icicle) {
    super.onCreate(icicle);
    
    setContentView(R.layout.step3);

    //init UI
    txtPhone = (EditText) findViewById(R.id.txtPhone);
  }
  
  public void step1Click(View v) {
    //get from step1 form
    Intent j = getIntent();
    
    //put detail age
    Intent i = new Intent(this, WizardUseBundleActivity.class);
    i.putExtras(j);
    i.putExtra("phone", txtPhone.getText().toString());
    
    //move bundle to step3
    startActivity(i);
  }
  
}
