/**
 * http://iziroi.9xkun.com
 *
 * LICENSE
 *
 * This source file is belong to iziroi.9xkun.com. Please come to this site and
 * get more source code. Can send email to me at: phantichhoang@gmail.com
 *
 * @copyright Copyright (c) 2013-2014 iziroi
 * @author hoangpt
 * @version $Id$
 * @since
 */

package com.hoangphan.wizard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;

/**
 *
 * @author hoangpt
 */
public class Step1 extends Activity {
  private EditText txtName;
  private EditText txtAge;
  private RadioButton radMale;

  /**
   * Called when the activity is first created.
   */
  @Override
  public void onCreate(Bundle icicle) {
    super.onCreate(icicle);
    setContentView(R.layout.step1);    
    
    //init ui
    txtName = (EditText) findViewById(R.id.txtName);
  }
  
  public void step2Click(View v){
    //save all information to bundle
    Bundle bundle = new Bundle();
    String name = txtName.getText().toString();
    bundle.putString("name", name);
    
    Intent i = new Intent(this, Step2.class);
    i.putExtras(bundle);
    startActivity(i);
  }
}
