package com.hoangphan.wizard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import java.util.Set;

public class WizardUseBundleActivity extends Activity {

  /**
   * Called when the activity is first created.
   */
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);
  }
  
  public void step1Click(View v){
    startActivity(new Intent(WizardUseBundleActivity.this, Step1.class));  
  }

  @Override
  protected void onResume() {
    super.onResume();
    Intent data = getIntent();
    TextView txtInfo = (TextView) findViewById(R.id.txtInfo);
    
    //not check anything, request_code or result_code
    Bundle b = data.getExtras();
    if(null != b){
      Set<String> keys = b.keySet();
      for (String key : keys) {
        String value = b.getString(key);
        if(null != value){
          txtInfo.append("\nYour "+key+": "+value);
        }
      }
    }
  }
}
