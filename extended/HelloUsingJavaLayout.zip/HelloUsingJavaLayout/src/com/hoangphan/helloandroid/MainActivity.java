package com.hoangphan.helloandroid;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Example of app where layout and string are define in javacode.
 * Another will define in xml and strings.xml
 *
 * @author hoangpt
 */
public class MainActivity extends Activity {

  /**
   * Called when the activity is first created.
   */
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    //Init String use in app
    String appName = "SayHello Application";
    String windowText
            = "Press the button below to receive "
            + "a friendly greeting from Android.";
    String buttonLabel = "Show Greeting";

    //define layout, use linear layout vertical
    LinearLayout mainWindow = new LinearLayout(this);
    mainWindow.setOrientation(LinearLayout.VERTICAL);
    setTitle(appName);

    //define 1 element, call textview
    TextView label = new TextView(this);
    label.setText(windowText);
    mainWindow.addView(label); //add to layout

    //define 1 button
    Button greetingButton = new Button(this);
    greetingButton.setText(buttonLabel);
    greetingButton.setOnClickListener(new Toaster()); //define class for event
    mainWindow.addView(greetingButton);
    setContentView(mainWindow);
  }

  /**
   * Implements View.ClickListener. Uses the named inner class approach: see
   * later tutorial section on handling GUI events.
   */
  private class Toaster implements OnClickListener {

    /**
     * Creates a Toast (temporary message) when button is clicked.
     */
    @Override
    public void onClick(View clickedButton) {
      String greetingText = "Hello from Android!";
      Toast tempMessage
              = Toast.makeText(
                      MainActivity.this,
                      greetingText,
                      Toast.LENGTH_SHORT);
      tempMessage.show();
    }
  }
}
