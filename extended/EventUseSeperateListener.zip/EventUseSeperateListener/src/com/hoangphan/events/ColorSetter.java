/**
 * http://iziroi.9xkun.com
 *
 * LICENSE
 *
 * This source file is belong to iziroi.9xkun.com. Please come to this site and
 * get more source code. Can send email to me at: phantichhoang@gmail.com
 *
 * @copyright Copyright (c) 2013-2014 iziroi
 * @author hoangpt
 * @version $Id$
 * @since
 */

package com.hoangphan.events;

import android.app.Activity;
import android.view.View;

/**
 * Seperate Listener in 1 class, so we
 *  can use for other class too
 * @author hoangpt
 */
public class ColorSetter implements View.OnClickListener {
  
  int colorCode;
  private Activity currentActivity;
  
  
  ColorSetter(int colorCode, Activity currentActivity) {
        this.colorCode = colorCode;
        this.currentActivity = currentActivity;
  }

  public void onClick(View v) {
    ((EventUseSeperateListenerActivity) currentActivity)
            .setRegionColor(colorCode);
  }
}
