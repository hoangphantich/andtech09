package com.hoangphan.helloandroid;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

/**
 * Can combine two method. Use java to get component id. Then use java to define
 * ClickListener
 *
 * @author hoangpt
 */
public class HellobothActivity extends Activity {

  /**
   * Called when the activity is first created.
   */
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);

    Button greetingButton
            = (Button) findViewById(R.id.greeting_button);
    greetingButton.setOnClickListener(new Toaster());

  }

  /**
   * Implements View.ClickListener. Uses the named inner class approach: see
   * later tutorial section on handling GUI events.
   */
  private class Toaster implements OnClickListener {

    /**
     * Creates a Toast (temporary message) when button is pressed.
     */
    @Override
    public void onClick(View clickedButton) {
      String greetingText = getString(R.string.greeting_text);
      Toast tempMessage
              = Toast.makeText(HellobothActivity.this,
                      greetingText,
                      Toast.LENGTH_SHORT);
      tempMessage.show();
    }
  }
}
