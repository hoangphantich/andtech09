/**
 * http://iziroi.9xkun.com
 *
 * LICENSE
 *
 * This source file is belong to iziroi.9xkun.com. Please come to this site and
 * get more source code. Can send email to me at: phantichhoang@gmail.com
 *
 * @copyright Copyright (c) 2013-2014 iziroi
 * @author hoangpt
 * @version $Id$
 * @since
 */
package com.hoangphan.wizard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class WizardUseForResultActivity extends Activity {

  private TextView txtInfo;

  /**
   * Called when the activity is first created.
   */
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);

    //init ui
    txtInfo = (TextView) findViewById(R.id.txtInfo);
  }

  public void step1Click(View v) {
    Intent i1 = new Intent(this, Step1.class);
    startActivityForResult(i1, Constant.REQUEST_FROMMAIN_TO1);
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    if (resultCode == RESULT_OK) {
      switch (requestCode) {
        case Constant.REQUEST_FROMMAIN_TO1:
          //step1 finish, then get data from intent
          txtInfo.append("\nYour name:" + data.getStringExtra("name"));

          //move right to step2
          Intent i2 = new Intent(this, Step2.class);
          startActivityForResult(i2, Constant.REQUEST_FROMMAIN_TO2);
          break;

        case Constant.REQUEST_FROMMAIN_TO2:
          //step2 finish
          txtInfo.append("\nYour age:" + data.getStringExtra("age"));

          //start step3
          Intent i3 = new Intent(this, Step3.class);
          startActivityForResult(i3, Constant.REQUEST_FROMMAIN_TO3);
          break;

        case Constant.REQUEST_FROMMAIN_TO3:
          txtInfo.append("\nYour phone:" + data.getStringExtra("phone"));
          break;
      }
    } else { //other request code
      Toast.makeText(this, "Not support cancel button", Toast.LENGTH_SHORT).show();
    }

  }
}
