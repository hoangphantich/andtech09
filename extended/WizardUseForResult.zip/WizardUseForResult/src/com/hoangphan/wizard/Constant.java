/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.hoangphan.wizard;

/**
 *
 * @author hoangpt
 */
class Constant {
  static final int REQUEST_FROMMAIN_TO1 = 100;
  static final int REQUEST_FROMMAIN_TO2 = 200;
  static final int REQUEST_FROMMAIN_TO3 = 300;
  
}
