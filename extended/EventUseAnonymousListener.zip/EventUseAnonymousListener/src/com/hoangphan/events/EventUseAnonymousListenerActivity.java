/**
 * http://iziroi.9xkun.com
 *
 * LICENSE
 *
 * This source file is belong to iziroi.9xkun.com. Please come to this site and
 * get more source code. Can send email to me at: phantichhoang@gmail.com
 *
 * @copyright Copyright (c) 2013-2014 iziroi
 * @author hoangpt
 * @version $Id$
 * @since
 */
package com.hoangphan.events;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioButton;

public class EventUseAnonymousListenerActivity extends Activity {

  private View regionColor;
        
  /**
   * Called when the activity is first created.
   */
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);

    regionColor = findViewById(R.id.color_region);
    Button b1 = (Button) findViewById(R.id.button1);
    Button b2 = (Button) findViewById(R.id.button2);
    Button b3 = (Button) findViewById(R.id.button3);
    RadioButton r1 = (RadioButton) findViewById(R.id.radio_button1);
    RadioButton r2 = (RadioButton) findViewById(R.id.radio_button2);
    RadioButton r3 = (RadioButton) findViewById(R.id.radio_button3);
    
    //button1
    b1.setOnClickListener(new OnClickListener() {

      public void onClick(View v) {
        setRegionColor(Color.RED);
      }
    });
    
    //button2
    b2.setOnClickListener(new OnClickListener() {

      public void onClick(View v) {
        setRegionColor(Color.BLUE);
      }
    });
    
    //button3
    b3.setOnClickListener(new OnClickListener() {

      public void onClick(View v) {
        setRegionColor(Color.YELLOW);
      }
    });
    
    //button1
    r1.setOnClickListener(new OnClickListener() {

      public void onClick(View v) {
        setRegionColor(Color.RED);
      }
    });
    
    //button2
    r2.setOnClickListener(new OnClickListener() {

      public void onClick(View v) {
        setRegionColor(Color.BLUE);
      }
    });
    
    //button3
    r3.setOnClickListener(new OnClickListener() {

      public void onClick(View v) {
        setRegionColor(Color.YELLOW);
      }
    });
  }

  /**
   * Sets the color of the color region.
   */
  private void setRegionColor(int color) {
    regionColor.setBackgroundColor(color);
  }
}
