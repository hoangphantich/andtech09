/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.hoangphan.wizard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

/**
 *
 * @author hoangpt
 */
public class Step1 extends Activity {
  private EditText txtName;

  /**
   * Called when the activity is first created.
   */
  @Override
  public void onCreate(Bundle icicle) {
    super.onCreate(icicle);
    setContentView(R.layout.step1);
    
    //init UI
    txtName = (EditText) findViewById(R.id.txtName);
  }
  
  public void step2Click(View v){
    //put to tracker
    WizardApplication app = WizardApplication.getInstance();
    app.setTxtName(txtName.getText().toString()); 
    
    //start2
    startActivity(new Intent(this, Step2.class));
    finish();
  }
}
