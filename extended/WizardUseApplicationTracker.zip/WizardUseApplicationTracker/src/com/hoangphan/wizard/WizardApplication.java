/**
 * http://iziroi.9xkun.com
 *
 * LICENSE
 *
 * This source file is belong to iziroi.9xkun.com. Please come to this site and
 * get more source code. Can send email to me at: phantichhoang@gmail.com
 *
 * @copyright Copyright (c) 2013-2014 iziroi
 * @author hoangpt
 * @version $Id$
 * @since
 */

package com.hoangphan.wizard;

import android.app.Application;
import android.content.Context;

/**
 *
 * @author hoangpt
 */
public class WizardApplication extends Application {
	private static WizardApplication instance = new WizardApplication();

	public static WizardApplication getInstance() {
			synchronized (WizardApplication.class) {
				if (instance == null) {
					instance = new WizardApplication();
				}
			}
		return instance;
	}

  private String txtName;
  private String txtAge;
  private String txtPhone;

  public String getTxtName() {
    return txtName;
  }

  public void setTxtName(String txtName) {
    this.txtName = txtName;
  }

  public String getTxtAge() {
    return txtAge;
  }

  public void setTxtAge(String txtAge) {
    this.txtAge = txtAge;
  }

  public String getTxtPhone() {
    return txtPhone;
  }

  public void setTxtPhone(String txtPhone) {
    this.txtPhone = txtPhone;
  }

  
}
