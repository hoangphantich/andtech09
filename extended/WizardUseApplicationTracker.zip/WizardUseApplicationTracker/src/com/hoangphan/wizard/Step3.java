/**
 * http://iziroi.9xkun.com
 *
 * LICENSE
 *
 * This source file is belong to iziroi.9xkun.com. Please come to this site and
 * get more source code. Can send email to me at: phantichhoang@gmail.com
 *
 * @copyright Copyright (c) 2013-2014 iziroi
 * @author hoangpt
 * @version $Id$
 * @since
 */

package com.hoangphan.wizard;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

/**
 *
 * @author hoangpt
 */
public class Step3 extends Activity {
  private EditText txtPhone;

  /**
   * Called when the activity is first created.
   */
  @Override
  public void onCreate(Bundle icicle) {
    super.onCreate(icicle);
    setContentView(R.layout.step3);
    
    //init UI
    txtPhone = (EditText) findViewById(R.id.txtPhone);
  }
  
  public void finishClick(View v){
    //set to tracker
    WizardApplication app = WizardApplication.getInstance();
    app.setTxtPhone(txtPhone.getText().toString()); 
  
    //back to main
    finish();
  }
  
}
