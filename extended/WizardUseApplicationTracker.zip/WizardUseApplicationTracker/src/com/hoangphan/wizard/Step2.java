/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.hoangphan.wizard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

/**
 *
 * @author hoangpt
 */
public class Step2 extends Activity {
  private EditText txtAge;

  /**
   * Called when the activity is first created.
   */
  @Override
  public void onCreate(Bundle icicle) {
    super.onCreate(icicle);
    setContentView(R.layout.step2);
    
    //init UI
    txtAge = (EditText) findViewById(R.id.txtAge);
  }
  
  public void step3Click(View v){
    //set to tracker
    WizardApplication app = WizardApplication.getInstance();
    app.setTxtAge(txtAge.getText().toString()); 
  
    //start3
    startActivity(new Intent(this, Step3.class));
    finish();
  }
  
}
