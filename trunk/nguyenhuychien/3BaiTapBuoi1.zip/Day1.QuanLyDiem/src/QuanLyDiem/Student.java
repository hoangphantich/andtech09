package QuanLyDiem;

public class Student {
private String name;
private int id;
private String classroom;
private int basicjava;
private int advancejava;
private int cshape;
private int advancecshape;
private int rdbms;
private int sql;
private double average;
private String rank;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getClassroom() {
	return classroom;
}
public void setClassroom(String classroom) {
	this.classroom = classroom;
}
public int getBasicjava() {
	return basicjava;
}
public void setBasicjava(int basicjava) {
	this.basicjava = basicjava;
}
public int getAdvancejava() {
	return advancejava;
}
public void setAdvancejava(int advancejava) {
	this.advancejava = advancejava;
}
public int getCshape() {
	return cshape;
}
public void setCshape(int cshape) {
	this.cshape = cshape;
}
public int getAdvancecshape() {
	return advancecshape;
}
public void setAdvancecshape(int advancecshape) {
	this.advancecshape = advancecshape;
}
public int getRdbms() {
	return rdbms;
}
public void setRdbms(int rdbms) {
	this.rdbms = rdbms;
}
public int getSql() {
	return sql;
}
public void setSql(int sql) {
	this.sql = sql;
}
public double getAverage() {
	return average;
}
public void setAverage(double average) {
	this.average = average;
}
public String getRank() {
	return rank;
}
public void setRank(String rank) {
	this.rank = rank;
}

}
