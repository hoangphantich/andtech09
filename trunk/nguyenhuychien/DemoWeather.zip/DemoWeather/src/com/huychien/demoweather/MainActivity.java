package com.huychien.demoweather;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {
	;
	ArrayList<String> dayList;
	ArrayList<String> iconList;
	ArrayList<String> conditionList;
	ImageView imgcurrent, ivDay1, ivDay2, ivDay3, ivDay4;
	String nang = "40do", mua = "mua to", gio = "gio lon";
	EditText edtLocation;
	Button btnOk;
	TextView edtNang, edtMua, edtGio, edtDay;
	private URL url;
	private XMLReader reader;
	int i = 0;
	private WeatherHandler handler;
	final static String Previmeteo = "http://api.previmeteo.com/ef71899f020d203c31f5cd64e8887155/ig/api?weather=";
	final static String PrevimeteoWeather = "http://api.previmeteo.com";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		imgcurrent = (ImageView) findViewById(R.id.imgcurrent);
		ivDay1 = (ImageView) findViewById(R.id.ivDay1);
		ivDay2 = (ImageView) findViewById(R.id.ivDay2);
		ivDay3 = (ImageView) findViewById(R.id.ivDay3);
		ivDay4 = (ImageView) findViewById(R.id.ivDay4);
		ivDay1.setOnClickListener(this);
		ivDay2.setOnClickListener(this);
		ivDay3.setOnClickListener(this);
		ivDay4.setOnClickListener(this);
		edtLocation = (EditText) findViewById(R.id.edtLocation);
		btnOk = (Button) findViewById(R.id.btnOk);
		edtGio = (TextView) findViewById(R.id.txtGio);
		edtMua = (TextView) findViewById(R.id.txtMua);
		edtNang = (TextView) findViewById(R.id.txtNang);
		edtDay = (TextView) findViewById(R.id.txt);
		btnOk.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				String location = edtLocation.getText().toString();
				loadData(location);

			}
		});
	}

	protected void loadData(String location) {
		try {
			url = new URL(Previmeteo + location);
			SAXParserFactory spf = SAXParserFactory.newInstance();
			SAXParser sp = spf.newSAXParser();

			reader = sp.getXMLReader();
			handler = new WeatherHandler();
			reader.setContentHandler(handler);
			// Intent intent = new Intent(Intent.ACTION_VIEW,
			// Uri.parse(url.toString()));
			// startActivity(intent);
			new Thread(new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					try {
						reader.parse(new InputSource(url.openStream()));
						//i = 1;
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SAXException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					runOnUiThread(new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							edtDay.setText(handler.getDate());
							edtNang.setText(handler.getHumidity());
							edtMua.setText(handler.getTempC());
							edtGio.setText(handler.getCondition());
							if (true) {
								
								loadIcon(handler.getIcon(), imgcurrent);
								dayList = handler.getDayList();
								iconList = handler.getIconList();
								conditionList = handler.getConditionList();
								ImageView[] arrayIv = { ivDay1, ivDay2, ivDay3, ivDay4 };
								for (int i = 0; i < arrayIv.length; i++) {
									loadIcon(iconList.get(i), arrayIv[i]);
								}
							}
						}
					});
				}
			}).start();
			Toast.makeText(getApplicationContext(), "da den day roi",
					Toast.LENGTH_LONG).show();
			
		} catch (Exception e) {
			Toast.makeText(getApplicationContext(), "Retype location",
					Toast.LENGTH_LONG).show();
			edtLocation.requestFocus();
			e.printStackTrace();
		}

	}

	private void loadIcon(String url, ImageView img) {
		// try {
		// URL url2 = new URL(PrevimeteoWeather + url);
		// Bitmap bm = BitmapFactory.decodeStream(url2.openConnection()
		// .getInputStream());
		// img.setImageBitmap(bm);
		// } catch (Exception e) {
		// }
		String path = PrevimeteoWeather + url;
		new ImageDownloader(img).execute(path);
		// try {
		// URL uRl = new URL(path);
		// URLConnection con = uRl.openConnection();
		//
		// //request toi anh (config), khong co cung ok -> GET
		// con.setAllowUserInteraction(true);
		//
		// //tao input stream toi anh
		// InputStream is = con.getInputStream();
		//
		// //hien thi, binary anh
		// Bitmap bm = BitmapFactory.decodeStream(is);
		// img.setImageBitmap(bm);
		// } catch (MalformedURLException e) {
		// } catch (IOException e){
		// }
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.weather, menu);
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.about:
			Intent intent = new Intent(MainActivity.this, AboutActivity.class);
			startActivity(intent);

			break;
		case R.id.setting:
			Intent intent2 = new Intent(MainActivity.this, SetingActivity.class);
			startActivity(intent2);
			break;

		}
		return false;
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.ivDay1:
			clickImage(ivDay1, imgcurrent, 1);
			break;

		case R.id.ivDay2:
			clickImage(ivDay2, imgcurrent, 2);
			break;
		case R.id.ivDay3:
			clickImage(ivDay3, imgcurrent, 3);
			break;
		case R.id.ivDay4:
			clickImage(ivDay4, imgcurrent, 4);
			break;
		}

	}

	private void clickImage(ImageView ivDay, ImageView imgcurrent, int index) {
		imgcurrent.setImageDrawable(ivDay.getDrawable());
		edtNang.setText(dayList.get(index - 1));
		edtDay.setText("");
		edtMua.setText("");
		edtGio.setText(conditionList.get(index - 1));

	}

	class ImageDownloader extends AsyncTask<String, Void, Void> {
		ImageView img;

		public ImageDownloader(ImageView img) {
			this.img = img;
		}

		@Override
		protected Void doInBackground(String... params) {
			String path = params[0];

			try {
				URL url = new URL(path);
				URLConnection con = url.openConnection();

				// request toi anh (config), khong co cung ok -> GET
				con.setAllowUserInteraction(true);

				// tao input stream toi anh
				InputStream is = con.getInputStream();

				// hien thi, binary anh
				final Bitmap bm = BitmapFactory.decodeStream(is);
				Log.d("anh", bm.toString());

				runOnUiThread(new Runnable() {

					@Override
					public void run() {
						img.setImageBitmap(bm); // display anh tren thread chinh
						Log.d("hien thi anh", bm.toString());
					}
				});

			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			return null;
		}

	}
}
