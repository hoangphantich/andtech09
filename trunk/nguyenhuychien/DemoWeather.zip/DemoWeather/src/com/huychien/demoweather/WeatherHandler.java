package com.huychien.demoweather;

import java.util.ArrayList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class WeatherHandler extends DefaultHandler {
	public String date, tempF, tempC, humidity, condition, icon;
	ArrayList<String> dayList = new ArrayList<String>();
	ArrayList<String> iconList = new ArrayList<String>();
	ArrayList<String> conditionList = new ArrayList<String>();
	int oder = 0;

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		String data = "";
		if (localName.equals("forecast_date")) {
			setDate(attributes.getValue("data"));
		} else if (localName.equals("temp_f")) {
			setTempF(attributes.getValue("data") + " *F");
		} else if (localName.equals("temp_c")) {
			setTempC(attributes.getValue("data") + " *C");
		}

		else if (localName.equals("humidity")) {
			setHumidity(attributes.getValue("data"));
		} else if (localName.equals("forecast_conditions")) {
			oder = 1;
		} else if (localName.equals("icon")) {
			data = attributes.getValue("data");
			if (oder == 0)
				setIcon(data);
			else
				setIcon(data);
				iconList.add(data);
		} else if (localName.equals("day_of_week")) {
			if (oder != 0) {
				dayList.add(getWeekDay(attributes.getValue("data")));
			}
		} else if (localName.equals("condition")) {
			data = attributes.getValue("data");
			if (oder == 0) {
				setCondition(data);
			} else
				conditionList.add(data);
		}

	}

	public ArrayList<String> getDayList() {
		return dayList;
	}

	public void setDayList(ArrayList<String> dayList) {
		this.dayList = dayList;
	}

	public ArrayList<String> getIconList() {
		return iconList;
	}

	public void setIconList(ArrayList<String> iconList) {
		this.iconList = iconList;
	}

	public ArrayList<String> getConditionList() {
		return conditionList;
	}

	public void setConditionList(ArrayList<String> conditionList) {
		this.conditionList = conditionList;
	}

	String getWeekDay(String day) {
		if (day.equals("Mon")) {
			return "Monday";
		} else if (day.equals("Tue")) {
			return "Tuesday";
		} else if (day.equals("Wed")) {
			return "Wednesday";
		} else if (day.equals("Thu")) {
			return "Thursday";
		} else if (day.equals("Fri")) {
			return "Friday";
		} else if (day.equals("Sat")) {
			return "Saturday";
		}
		return "Sunday";
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTempF() {
		return tempF;
	}

	public void setTempF(String tempF) {
		this.tempF = tempF;
	}

	public String getTempC() {
		return tempC;
	}

	public void setTempC(String tempC) {
		this.tempC = tempC;
	}

	public String getHumidity() {
		return humidity;
	}

	public void setHumidity(String humidity) {
		this.humidity = humidity;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public int getOder() {
		return oder;
	}

	public void setOder(int oder) {
		this.oder = oder;
	}

}
