/** Automatically generated file. DO NOT MODIFY */
package com.huychien.demoweather;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}