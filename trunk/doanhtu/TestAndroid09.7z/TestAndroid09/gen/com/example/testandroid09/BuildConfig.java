/** Automatically generated file. DO NOT MODIFY */
package com.example.testandroid09;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}