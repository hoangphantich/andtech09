package com.example.testandroid09;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class Information extends Activity{
	
	private TextView txtName,txtNumber,txtCerfiticate,txtFavorite,txtMore;
	private Button btnClose;
	private String strName,strNumber,strCerfiticate,strBook,strNewsPaper,strCoding,strMore;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.infomation);
		txtName = (TextView)findViewById(R.id.txtName);
		txtNumber = (TextView)findViewById(R.id.txtNumber);
		txtCerfiticate = (TextView)findViewById(R.id.txtCerfiticate);
		txtMore = (TextView)findViewById(R.id.txtMore);
		txtFavorite = (TextView)findViewById(R.id.txtFavorite);
		btnClose = (Button)findViewById(R.id.btnClose);
		Intent i = getIntent();
		Bundle b = i.getExtras();
		
		strName =  b.getString("Name");
		strNumber = b.getString("Number");
		strCerfiticate = b.getString("Cerfiticate");
		strBook = b.getString("Book");
		if(strBook == null)
		{
			strBook = "";
		}
		strNewsPaper =  b.getString("Newspaper");
		if(strNewsPaper == null)
		{
			strNewsPaper = "";
		}
		strCoding  = b.getString("Coding");
		if(strCoding == null)
		{
			strCoding = "";
		}
		strMore =  b.getString("More");
		
		txtName.setText(strName);
		txtNumber.setText(strNumber);
		txtCerfiticate.setText(strCerfiticate);
		txtFavorite.setText(strBook+"-"+strNewsPaper+"-"+strCoding);
		txtMore.setText(strMore);
		
		
		btnClose.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(Information.this,BillActivity.class);
				Bundle bundle = new Bundle();
				bundle.putString("name", strName);
				intent.putExtras(bundle);
				startActivity(intent);
			}
		});
		
	}

}
