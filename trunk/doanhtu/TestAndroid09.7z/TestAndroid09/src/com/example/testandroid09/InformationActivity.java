package com.example.testandroid09;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;


public class InformationActivity extends Activity {
	
	private EditText edtName,edtNumber,edtMore;
	private RadioButton rdoMedium,rdoSmall,rdoHigh;
	private RadioGroup rdoGroup;
	private CheckBox ckNewsPaper,ckBook,ckCoding;
	private Button btnSubmit;
	private TextView txt1,txt2,txt3,txt4;
	private String strName,strNumber,strMore,strCerfiticate,strBook,strNewsPaper,strCoding;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_information);
		
		edtName =(EditText)findViewById(R.id.edtName);
		edtNumber = (EditText)findViewById(R.id.edtNumber);
		edtMore = (EditText)findViewById(R.id.edtMore);
		rdoGroup  =(RadioGroup)findViewById(R.id.rdoGroup);
		rdoHigh  =(RadioButton)findViewById(R.id.rdoHigh);
		rdoMedium = (RadioButton)findViewById(R.id.rdoMedium);
		rdoSmall = (RadioButton)findViewById(R.id.rdoSmall);
		ckBook = (CheckBox)findViewById(R.id.ckBook);
		ckNewsPaper = (CheckBox)findViewById(R.id.ckNewsPaper);
		ckCoding  =(CheckBox)findViewById(R.id.ckCoding);
		btnSubmit  =(Button)findViewById(R.id.btnSubmit);
		txt1 = (TextView)findViewById(R.id.txt1);
		txt1.setBackgroundColor(Color.BLUE);
		txt2 = (TextView)findViewById(R.id.txt2);
		txt2.setBackgroundColor(Color.BLUE);
		txt3 = (TextView)findViewById(R.id.txt3);
		txt3.setBackgroundColor(Color.BLUE);
		txt4 = (TextView)findViewById(R.id.txt4);
		txt4.setBackgroundColor(Color.BLUE);
		btnSubmit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				strName = edtName.getText().toString();
				strNumber = edtNumber.getText().toString();
				strMore =  edtMore.getText().toString();
				
				int i = rdoGroup.getCheckedRadioButtonId();
				
				if(i == R.id.rdoMedium)
				{
					strCerfiticate = "Trung cấp" ;
				}
				else if(i==R.id.rdoSmall) {
					strCerfiticate = "Cao đẳng"; 
				}
				else 
				{
					strCerfiticate = "Đại học";
				}
				
				
				Intent intent = new Intent(InformationActivity.this, Information.class);
				Bundle bundle = new Bundle();
				bundle.putString("Name", strName);
				bundle.putString("Number", strNumber);
				bundle.putString("More",strMore);
				bundle.putString("Cerfiticate", strCerfiticate);
				if (ckBook.isChecked())
				{
					strBook = "Đọc sách";
					bundle.putString("Book",strBook);
				}
				if(ckCoding.isChecked())
				{
					strCoding= "Đọc coding";
					bundle.putString("Coding", strCoding);
				}
				if(ckNewsPaper.isChecked())
				{
					strNewsPaper= "Đọc báo";
					bundle.putString("Newspaper", strNewsPaper);
				}
				intent.putExtras(bundle);
				startActivity(intent);
			}
		});
		
		
		
	}
}
