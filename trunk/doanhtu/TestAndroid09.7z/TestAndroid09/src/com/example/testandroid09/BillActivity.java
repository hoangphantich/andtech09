package com.example.testandroid09;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class BillActivity extends Activity{
	
	private TextView txtInformation,txtTT,txtTotal;
	private EditText edtName,edtQuantity,edtTotalCustomer,edtTotalVip,edtTotalDT;
	private Button btnTinhTT,btnTiep,btnThongKe;
	private String strName;
	private int countCustomer=0,countTotal=0,countTotalVip=0;
	private CheckBox ckVip;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bill);
		
		txtInformation = (TextView)findViewById(R.id.txtInformation);
		txtInformation.setBackgroundColor(Color.YELLOW);
		txtTT = (TextView)findViewById(R.id.txtTT);
		txtTT.setBackgroundColor(Color.YELLOW);
		txtTotal = (TextView)findViewById(R.id.txtTotal);
		edtName = (EditText)findViewById(R.id.edtName);
		edtQuantity = (EditText)findViewById(R.id.edtQuantity);
		edtTotalCustomer = (EditText)findViewById(R.id.edtTotalCustomer);
		edtTotalVip = (EditText)findViewById(R.id.edtTotalVip);
		edtTotalDT= (EditText)findViewById(R.id.edtTotalDT);
		btnTinhTT =  (Button)findViewById(R.id.btnTinh);
		btnTiep = (Button)findViewById(R.id.btnContinue);
		btnThongKe = (Button)findViewById(R.id.btnStatistic);
		ckVip = (CheckBox)findViewById(R.id.ckVip);
		
		Intent i = getIntent();
		Bundle b = i.getExtras();
		
		strName = b.getString("name");
		edtName.setText(strName);
				
		btnTinhTT.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				int i  = Integer.parseInt(edtQuantity.getText().toString());
				int total = i*10000;
				txtTotal.setText(Integer.toString(total));
				countTotal+=total;
				if(ckVip.isChecked())
				{
					countTotalVip++;
				}
				countCustomer++;
			}
		});
		
		btnTiep.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(BillActivity.this, InformationActivity.class);
				startActivity(intent);
			}
		});
		btnThongKe.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				edtTotalVip.setText(Integer.toString(countTotalVip));
				edtTotalDT.setText(Integer.toString(countTotal));
				edtTotalCustomer.setText(Integer.toString(countCustomer));
			}
		});
	}

}
