package com.example.devilboss1;

import java.util.HashMap;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

/**
 * @author MrSoul2
 *
 */
public class MainActivity extends Activity {

	Button btnRed;
	Button btnGreen;
	Button btnYellow;
	RadioGroup rgColor;
	RadioButton rdRed;
	RadioButton rdGreen;
	RadioButton rdYeloow;
	TextView txtColor;
	HashMap<Button, RadioButton> radioMaps;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		btnRed = (Button) findViewById(R.id.btnRed);
		btnGreen = (Button) findViewById(R.id.btnGreen);
		btnYellow = (Button) findViewById(R.id.btnYellow);
		rgColor = (RadioGroup) findViewById(R.id.rgColor);
		rdRed = (RadioButton) findViewById(R.id.rdRed);
		rdGreen = (RadioButton) findViewById(R.id.rdGreen);
		rdYeloow = (RadioButton) findViewById(R.id.rdYellow);
		txtColor = (TextView) findViewById(R.id.txtColor);

		radioMaps = new HashMap<Button, RadioButton>();
		radioMaps.put(btnRed, rdRed);
		radioMaps.put(btnGreen, rdGreen);
		radioMaps.put(btnYellow, rdYeloow);

		rgColor.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

			public void onCheckedChanged(RadioGroup group, int checkedId) {

				RadioButton checkedButton = (RadioButton) findViewById(checkedId);
				Toast.makeText(group.getContext(), checkedButton.getText(),
						Toast.LENGTH_SHORT).show();
				txtColor.setBackgroundColor(Color
						.parseColor((String) checkedButton.getTag()));

				// txtColor.setBackgroundColor(Color.GREEN);
			}
		});

	}

	/**
	 * Click button check RadioButton tương ứng
	 * 
	 * @param v
	 *            PDKIEN 23/3/2015
	 */
	public void onButtonClick(View v) {
		if (radioMaps.containsKey(v)) {
			RadioButton rd = radioMaps.get(v);
			rd.setChecked(true);
		}
	}
}
